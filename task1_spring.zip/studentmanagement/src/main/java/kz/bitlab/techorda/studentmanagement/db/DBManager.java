package kz.bitlab.techorda.studentmanagement.db;

import kz.bitlab.techorda.studentmanagement.model.Student;

import java.util.ArrayList;

public class DBManager {

    public static ArrayList<Student> studentList = new ArrayList<>();
    private static Long id = 6L;

    static {
        studentList.add(new Student(1L, "Maksat", "Smagulov", 98, "A"));
        studentList.add(new Student(2L, "Zhaksylyk", "Kasymbek", 89, "B"));
        studentList.add(new Student(3L, "Zhaksylyk 1", "Kasymbek", 89, "B"));
        studentList.add(new Student(4L, "Zhaksylyk 2", "Kasymbek", 89, "B"));
        studentList.add(new Student(5L, "Zhaksylyk 3", "Kasymbek", 89, "B"));
    }

    // getAllStudents();
    public static ArrayList<Student> getAllStudents(){
        return studentList;
    }

    // addStudent(Student student);

    public static void addStudent(Student student){
        student.setId(id);
        studentList.add(student);
        id++;
        DBManager.getMarkByExamPoints(student);
    }

    // getStudentById();
    public static Student getStudentById(Long id){
        for(Student stud : studentList) {
            if (stud.getId() == id) {
                return stud;
            }
        }
        return null;
    }
    // updateStudent(Long id, Student student)
    public static void updateStudent(Long id, Student student){
        for(Student stud : studentList){
            if (stud.getId()==id){
                studentList.set(Integer.parseInt(String.valueOf(id-1)),student);
            }
        }
        DBManager.getMarkByExamPoints(student);
    }

    // deleteStudent(Long id);
    public static void deleteStudent(Long id){
        Student s = new Student();
        for (Student student : studentList){
            if (student.getId()==id){
                s = student;
            }
        }
        studentList.remove(s);
    }

    public static void getMarkByExamPoints(Student student){
        if (student.getExam()>=60 && student.getExam()<=74){
            student.setMark("C");
        }else if (student.getExam()>=90){
            student.setMark("A");
        }
        else if (student.getExam()>=75 && student.getExam()<=89) {
            student.setMark("B");
        }
        else if (student.getExam()>=50 && student.getExam()<=59) {
            student.setMark("C");
        }else {
            student.setMark("F");
        }
    }
}
