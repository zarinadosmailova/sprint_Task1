package kz.bitlab.techorda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechordaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechordaApplication.class, args);
	}

}
