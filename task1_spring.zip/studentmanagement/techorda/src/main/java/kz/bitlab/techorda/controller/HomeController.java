package kz.bitlab.techorda.controller;

import kz.bitlab.techorda.db.DBManager;
import kz.bitlab.techorda.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;

import static kz.bitlab.techorda.db.DBManager.addStudent;

@Controller

public class HomeController {
    @GetMapping(value = "/")
    public String indexPage(Model model){
        ArrayList<Student> allStudents = DBManager.getAllStudent();
        model.addAttribute("allStudAttribute", allStudents);
        return "index";
    }

    @PostMapping(value = "/students/add")
    public String addStudents(@RequestParam(name = "name") String name,
                             @RequestParam(name = "surname") String surname,
                             @RequestParam(name = "exam") int exam, Model model) {
        Student student = new Student();
        student.setName(name);
        student.setSurname(surname);
        student.setExam(exam);

        DBManager.addStudent(student);
        ArrayList<Student> allStudents = DBManager.getAllStudent();
        model.addAttribute("allStudAttribute", allStudents);
        return "index";
    }

    @GetMapping(value = "/details/{id}")
    public String details(@PathVariable(name = "id") Long id, Model model){
        Student studentById = DBManager.getStudentById(id);
        model.addAttribute("student",studentById);
        return "details";
    }
}
