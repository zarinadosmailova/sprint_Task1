package kz.bitlab.techorda.db;

import kz.bitlab.techorda.model.Student;

import java.util.ArrayList;
import java.util.Objects;

public class DBManager {
    public static ArrayList<Student> studentList = new ArrayList<>();

    private static Long id = 3L;

    static {
        studentList.add(new Student(1L, "M", "S", 95,"A"));
        studentList.add(new Student(2L, "A", "D", 87,"B"));
    }


    public static ArrayList<Student> getAllStudent(){
        return studentList;
    }

    public static void addStudent(Student student){
        student.setId(id);
        studentList.add(student);
        id++;
        if(student.getExam()>60 && student.getExam()<74){
            student.setMark("C");
        } else if (student.getExam()>75 && student.getExam()<89){
            student.setMark("B");
        } else if (student.getExam()>50 && student.getExam()<59){
            student.setMark("D");
        } else if (student.getExam()>90) {
            student.setMark("A");
        } else {
            student.setMark("F");
        }
    }

    public static Student getStudentById(Long id) {
        for (Student stud : studentList) {
            if (stud.getId().equals(id)) {
                return stud;
            }
        }
        return null;
    }

    public static void updateStudent(Long id, Student student){
        for (Student stud : studentList) {
            if (stud.getId().equals(id)){
                studentList.set(Integer.parseInt(String.valueOf(id)), student);
            }
        }
    }

    public static void deleteStudent(Long id){
        for (Student stud : studentList) {
            if (stud.getId().equals(id)){
                studentList.remove(Integer.parseInt(String.valueOf(id)));
            }
        }
    }
}
