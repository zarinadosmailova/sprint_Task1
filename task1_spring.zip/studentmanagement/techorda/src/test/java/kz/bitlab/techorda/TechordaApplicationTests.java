package kz.bitlab.techorda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechordaApplicationTests {

	@Test
	void contextLoads() {
	}

}
